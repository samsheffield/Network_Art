// p5.js + Spacebrew!

var sb; // Variable to hold Spacebrew object

function setup() {
  createCanvas(600, 600);
  // Change this to name your app
  app_name = "My Spacebrew Client"; 
  // Create a Spacebrew client that can reconnect by itself
  sb = new Spacebrew.Client({reconnect:true});
  // Uncommenting this line will connect you to the IA Spacebrew server. Otherwise, you will be connected to the Spacebrew sandbox server.
  sb.server = "ixda.mica.edu"; 
  // Name of the client (appears in the Spacebrew admin panel)
  sb.name("Spacebrew example");
  // Useful description
  sb.description("Sends & receives booleans");
  // Set up publishers
  sb.addPublish( "mousePress", "boolean", "false" );
  // Set up subscribers
  sb.addSubscribe( "toggleBG", "boolean" );
  // Override Spacebrew events with our own functions
  sb.onBooleanMessage = onBooleanMessage;
  sb.onOpen = onOpen;
  // connect to Spacebrew
  sb.connect();
}

function draw() {
  // Nothing yet...
}

function mousePressed(){
  print("Mouse pressed");

  // Send message from mousePress publisher 
  sb.send("mousePress", "boolean", "true");
}

function mouseReleased(){
  print("Mouse released"); 
  sb.send("mousePress", "boolean", "false");
}

// This is called when Spacebrew connects to a server
function onOpen() {
  print("Connected as " + sb.name()); // Print name of client
}

// Spacebrew subscriber event handlers. Use to receive data.
function onBooleanMessage( name, value ){
  print (name + ": boolean message received: " + value);

  if(name === "toggleBG"){
    if (value) {
          background(255,255,0);
    } else {
          background(0);       
    }
  }
}

function onRangeMessage( name, value ){
  print (name + ": range message received: " + value);

  if(name === " "){
    if (value) {
          //
    } else {
          //     
    }
  }
}

function onStringMessage( name, value ){
  print (name + ": string message received: " + value);

  if(name === " "){
    if (value) {
          //
    } else {
          //     
    }
  }
}