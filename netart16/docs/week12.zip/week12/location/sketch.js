// City geolocation data using JSON

var city="";

function setup() {
  createCanvas(400, 400);
  // Request the data from telize and send it to the getLocation function
  loadJSON('http://www.telize.com/geoip', getLocation);
}

function draw() {
  background(255);
  text(city, 100, 100);
}

function getLocation(location) {
  //print(location); // Look at the resulting JSON OBJECT if you want detail
  city = location.city;
}