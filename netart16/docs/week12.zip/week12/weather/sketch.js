// Simplified weather example using JSON
// Based on Weather Example from p5js.org

var temperature;

function setup() {
  createCanvas(400, 400);
  // Request the data from openweathermap and send it to the gotWeather function
  loadJSON('http://api.openweathermap.org/data/2.5/weather?q=Baltimore&units=imperial', gotWeather);
}

function draw() {
  background(temperature);
}

function gotWeather(weather) {
  // Round the temperature results (main.temp) down and store in temperature
  temperature = floor(weather.main.temp);
}